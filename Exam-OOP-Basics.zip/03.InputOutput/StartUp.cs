﻿using AnimalCentre.Models;
using AnimalCentre.Models.Abstracts;
using AnimalCentre.Models.Contracts;
using System;
using System.Collections.Generic;

namespace AnimalCentre
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            controller.AnimalCentre animalCentre = new controller.AnimalCentre();

            var adopted = new List<IAnimal>();
            

            string input = Console.ReadLine();

            while (input != "End")
            {
                try
                {
                    string[] currentComannd = input.Split();

                    string typeCommand = currentComannd[0];

                    switch (typeCommand)
                    {

                        case "RegisterAnimal":
                            string type = currentComannd[1];
                            int energy = int.Parse(currentComannd[3]);
                            int happiness = int.Parse(currentComannd[4]);
                            int procedureTime = int.Parse(currentComannd[5]);

                            Console.WriteLine(animalCentre.RegisterAnimal(type, currentComannd[2], energy, happiness, procedureTime));
                            break;
                        case "Chip":
                            Console.WriteLine(animalCentre.Chip(currentComannd[1], int.Parse(currentComannd[2])));
                            break;
                        case "Vaccinate":
                            Console.WriteLine(animalCentre.Vaccinate(currentComannd[1], int.Parse(currentComannd[2])));
                            break;
                        case "Fitness":
                            Console.WriteLine(animalCentre.Fitness(currentComannd[1], int.Parse(currentComannd[2])));
                            break;
                        case "Play":
                            Console.WriteLine(animalCentre.Play(currentComannd[1], int.Parse(currentComannd[2])));
                            break;
                        case "DentalCare":
                            Console.WriteLine(animalCentre.DentalCare(currentComannd[1], int.Parse(currentComannd[2])));
                            break;
                        case "NailTrim":
                            Console.WriteLine(animalCentre.NailTrim(currentComannd[1], int.Parse(currentComannd[2])));
                            break;
                        case "Adopt":
                            Console.WriteLine(animalCentre.Adopt(currentComannd[1], currentComannd[2]));
                            break;
                        case "History":
                            Console.WriteLine(animalCentre.History(currentComannd[1]));
                            break;

                    }
                    
                }
                catch (ArgumentException ex)
                {

                    Console.WriteLine($"ArgumentException: {ex.Message}");
                }
                catch(InvalidOperationException exe)
                {
                    Console.WriteLine($"InvalidOperationException: {exe.Message}");
                }
                input = Console.ReadLine();
            }

        }
    }
}
