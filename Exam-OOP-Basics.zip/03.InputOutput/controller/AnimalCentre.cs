﻿using AnimalCentre.Models;
using AnimalCentre.Models.Animals;
using AnimalCentre.Models.Contracts;
using AnimalCentre.Models.Procedures;
using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalCentre.controller
{
    public class AnimalCentre
    {
        Hotel hotel = new Hotel();
        public string RegisterAnimal(string type, string name, int energy, int happiness, int procedureTime)
        {
            switch (type)
            {
                case "Cat":
                    var cat = new Cat(name, energy, happiness, procedureTime);
                    hotel.Accommodate(cat);
                    return $"Animal {cat.Name} registered successfully";
                case "Dog":
                    var dog = new Dog(name, energy, happiness, procedureTime);
                    hotel.Accommodate(dog);
                    return $"Animal {dog.Name} registered successfully";
                case "Lion":
                    var lion = new Lion(name, energy, happiness, procedureTime);
                    hotel.Accommodate(lion);
                    return $"Animal {lion.Name} registered successfully";
                case "Pig":
                    var pig = new Pig(name, energy, happiness, procedureTime);
                    hotel.Accommodate(pig);
                    return $"Animal {pig.Name} registered successfully";
            }
            return string.Empty;
        }

        public string Chip(string name, int procedureTime)
        {
            if (!hotel.Animals.ContainsKey(name))
            {
                throw new ArgumentException($"Animal {name} does not exist");
            }
            Chip chip = new Chip();
            chip.DoService(hotel.Animals[name], procedureTime);
            chip.procedureHistory.Add(hotel.Animals[name]);

            return $"{name} had chip procedure";
        }

        public string Vaccinate(string name, int procedureTime)
        {
            if (!hotel.Animals.ContainsKey(name))
            {
                throw new ArgumentException($"Animal {name} does not exist");
            }
            var currnetAnimal = hotel.Animals[name];
            Vaccinate vaccinate = new Vaccinate();
            vaccinate.DoService(currnetAnimal,procedureTime);
            vaccinate.procedureHistory.Add(currnetAnimal);

            return $"{name} had fitness procedure";
        }

        public string Fitness(string name, int procedureTime)
        {
            if (!hotel.Animals.ContainsKey(name))
            {
                throw new ArgumentException($"Animal {name} does not exist");
            }
            var currnetAnimal = hotel.Animals[name];
            Fitness fitness = new Fitness();
            fitness.DoService(currnetAnimal, procedureTime);
            fitness.procedureHistory.Add(currnetAnimal);

            return $"{name} had fitness procedure";
        }

        public string Play(string name, int procedureTime)
        {
            if (!hotel.Animals.ContainsKey(name))
            {
                throw new ArgumentException($"Animal {name} does not exist");
            }
            var currnetAnimal = hotel.Animals[name];
            Play play = new Play();
            play.DoService(currnetAnimal,procedureTime);
            play.procedureHistory.Add(currnetAnimal);
            return $"{name} was playing for {procedureTime} hours";
        }

        public string DentalCare(string name, int procedureTime)
        {
            if (!hotel.Animals.ContainsKey(name))
            {
                throw new ArgumentException($"Animal {name} does not exist");
            }
            var currnetAnimal = hotel.Animals[name];
            DentalCare dental = new DentalCare();
            dental.DoService(currnetAnimal,procedureTime);
            dental.procedureHistory.Add(currnetAnimal);

            return $"{name} had dental care procedure";
        }

        public string NailTrim(string name, int procedureTime)
        {
            if (!hotel.Animals.ContainsKey(name))
            {
                throw new ArgumentException($"Animal {name} does not exist");
            }
            var currnetAnimal = hotel.Animals[name];
            NailTrim nail = new NailTrim();
            nail.DoService(currnetAnimal, procedureTime);
            nail.procedureHistory.Add(currnetAnimal);

            return $"{name} had nail trim procedure";
        }

        public string Adopt(string animalName, string owner)
        {
            if (!hotel.Animals.ContainsKey(animalName))
            {
                throw new ArgumentException($"Animal {animalName} does not exist");
            }
            var currnetAnimal = hotel.Animals[animalName];
            if (currnetAnimal.IsChipped)
            {
                hotel.Adopt(animalName, owner);
                return $"{owner} adopted animal with chip";
            }
            else
            {
                hotel.Adopt(animalName, owner);
                return $"{owner} adopted animal without chip";
            }
        }

        public string History(string type)
        {
            switch (type)
            {
                case "Chip":
                    Chip chip = new Chip();
                    return chip.History();
                case "DentalCare":
                    DentalCare dental = new DentalCare();
                   return dental.History();
                case "Fitness":
                    Fitness fitness = new Fitness();
                    return fitness.History();
                case "NailTrim":
                    NailTrim nailTrim = new NailTrim();
                    return nailTrim.History();
                case "Paly":
                    Play play = new Play();
                    return play.History();
                case "Vaccinate":
                    Vaccinate vaccinate = new Vaccinate();
                    return vaccinate.History();     
            }
            return string.Empty;
        }     

    }
}
