﻿using AnimalCentre.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnimalCentre.Models
{
    public class Hotel : IHotel
    {
        private const int capacity = 10;
        public Dictionary<string, IAnimal> animals;
        
        public Hotel()
        {
            this.animals = new Dictionary<string, IAnimal>();
        }
        public int Capacity
        {
            get => capacity;
        }
        
        public IReadOnlyDictionary<string, IAnimal> Animals
        {
            get => this.animals;
        }


        public void Accommodate(IAnimal animal)
        {
            if (animals.Count == 10)
            {
                throw new InvalidOperationException("Not enough capacity");
            }
            if (Animals.ContainsKey(animal.Name))
            {
                throw new ArgumentException($"Animal {animal.Name} already exist");
            }
            animals[animal.Name] = animal;
        }

        public void Adopt(string animalName, string owner)
        {
            if (!this.Animals.ContainsKey(animalName))
            {
                throw new ArgumentException($"Animal {animalName} does not exist");
            }
            Animals[animalName].Owner = owner;
            Animals[animalName].IsAdopt = true;
            animals.Remove(animalName);

        }
    }
}

