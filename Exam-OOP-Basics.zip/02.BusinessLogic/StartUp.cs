﻿using System;

namespace AnimalCentre
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            controller.AnimalCentre animalCentre = new controller.AnimalCentre();

            string input = Console.ReadLine();

            while (input != "End")
            {
                try
                {
                    string[] currentComannd = input.Split();

                    string typeCommand = currentComannd[0];
                    string name = currentComannd[2];

                    switch (typeCommand)
                    {

                        case "RegisterAnimal":
                            string type = currentComannd[1];
                            int energy = int.Parse(currentComannd[3]);
                            int happiness = int.Parse(currentComannd[4]);
                            int procedureTime = int.Parse(currentComannd[5]);

                            Console.WriteLine(animalCentre.RegisterAnimal(type, name, energy, happiness, procedureTime));
                            break;
                        case "Chip":
                            name = currentComannd[1];
                            Console.WriteLine(animalCentre.Chip(name, int.Parse(currentComannd[2])));
                            break;
                        case "Vaccinate":
                            Console.WriteLine(animalCentre.Vaccinate(currentComannd[1], int.Parse(currentComannd[2])));
                            break;
                        case "Fitness":
                            Console.WriteLine(animalCentre.Fitness(currentComannd[1], int.Parse(currentComannd[2])));
                            break;
                        case "Play":
                            Console.WriteLine(animalCentre.Play(currentComannd[1], int.Parse(currentComannd[2])));
                            break;
                        case "DentalCare":
                            Console.WriteLine(animalCentre.DentalCare(currentComannd[1], int.Parse(currentComannd[2])));
                            break;
                        case "NailTrim":
                            Console.WriteLine(animalCentre.NailTrim(currentComannd[1], int.Parse(currentComannd[2])));
                            break;
                        case "Adopt":
                            Console.WriteLine(animalCentre.Adopt(currentComannd[1], currentComannd[2]));
                            break;
                        case "History":
                            Console.WriteLine(animalCentre.History(currentComannd[1]));
                            break;

                    }
                    
                }
                catch (Exception ex)
                {

                    Console.WriteLine($"{ex.Message}");
                }
                input = Console.ReadLine();
            }

        }
    }
}
