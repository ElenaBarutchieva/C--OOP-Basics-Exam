﻿using AnimalCentre.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnimalCentre.Models.Abstracts
{
    public abstract class Procedure : IProcedure
    {
        public List<IAnimal> procedureHistory;

        public Procedure()
        {
            this.procedureHistory = new List<IAnimal>();
        }

        public IReadOnlyCollection<IAnimal> ProcedureHistory
        {
            get => this.procedureHistory;
        }

        public virtual void DoService(IAnimal animal, int procedureTime)
        {

        }

        public string History()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"{this.GetType()}");
            foreach (var animal in this.ProcedureHistory)
            {
                sb.AppendLine($"    - {animal.Name} - Happiness: {animal.Happiness} - Energy: {animal.Energy}");
            }
            return sb.ToString().Trim();
        }
    }
}
